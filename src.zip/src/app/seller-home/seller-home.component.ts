import { Component, OnInit } from '@angular/core';
import { ProductService } from '../services/product.service';
import { product } from '../data-type';
import { faTrash } from '@fortawesome/free-solid-svg-icons';
import { faEdit } from '@fortawesome/free-solid-svg-icons';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-seller-home',
  templateUrl: './seller-home.component.html',
  styleUrls: ['./seller-home.component.css']
})
export class SellerHomeComponent implements OnInit {

  productList:undefined | product[];
  productMessage:undefined | string;
  FilterPrnm="";


  // maam shayd passwodr save na
  icon = faTrash;
  iconedit = faEdit
  constructor(private product:ProductService,private hp:HttpClient) {  }

  ngOnInit(): void {
      this.list();
      this.hp.post('http://localhost:8080/products',this.productList);
  }

  deleteProduct(id:number)
  {
    console.warn(id)
    this.product.deleteProduct(id).subscribe((result)=>{
        if(result)
        {
          this.productMessage="Product is deleted ! ";
          alert("Product is deleted ! ");
          this.list();
          this.hp.post('http://localhost:8080/products',this.productList);
          
        }
    })
  }

  list()
  {
    this.product.productList().subscribe((result)=>{
      if(result)
      {
        this.productList=result;
        this.hp.post('http://localhost:8080/products',this.productList);
      }
  })
  }

}
