import { Component ,OnInit} from '@angular/core';
import { signUp } from '../data-type';
import { SellerService } from '../services/seller.service';
import { Router } from '@angular/router';
import { FormBuilder,FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-seller-auth',
  templateUrl: './seller-auth.component.html',
  styleUrls: ['./seller-auth.component.css']
})
export class SellerAuthComponent implements OnInit{
  SellerFormValue ! : FormGroup;
  showLogin=false;
  authError:String ='';
  constructor ( private seller : SellerService , private router:Router,private frmblder : FormBuilder )  { }

  ngOnInit(): void { 

    this.SellerFormValue = this.frmblder.group({
      name:['',[Validators.required,Validators.maxLength(20)]],
      email:['',[Validators.required,Validators.pattern('[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$')]],
      password:['',[Validators.required,Validators.minLength(8),Validators.maxLength(12)]]
    })

    this.seller.reloadSeller();
  }
  get sendDataForm()
  {
    return this.SellerFormValue.controls
  }

  signUp(data:signUp):void
  {
    console.warn(data);
    this.seller.userSignUp(data);
    
  }

  openLogin()
  {
    this.showLogin = true;
  }
  openSignUp()
  {
    this.showLogin=false;
  }

  Login(data:signUp):void
  {
    this.seller.userLogin(data);
    this.seller.isLoginError.subscribe((isError)=>
    {
        // console.warn(isError);
        if(isError)
        {
          this.authError="Email  or password is not correct ! ";
        }
    })
    
  }
}
