import { Component, OnInit } from '@angular/core';
import { cart, Login, product, signUp } from '../data-type';
import { ProductService } from '../services/product.service';
import { UserService } from '../services/user.service';
import { FormBuilder,FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-user-auth',
  templateUrl: './user-auth.component.html',
  styleUrls: ['./user-auth.component.css']
})
export class UserAuthComponent implements OnInit{

  UserFormValue ! : FormGroup;
  showLogin:boolean=true;
  authError:string="";
  

  constructor(private user:UserService,private product:ProductService,private frmblder : FormBuilder) {  }

  ngOnInit(): void {

      this.UserFormValue = this.frmblder.group({
        name:['',[Validators.required,Validators.maxLength(20)]],
        email:['',[Validators.required,Validators.pattern('[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$')]],
        password:['',[Validators.required,Validators.minLength(8),Validators.maxLength(12)]]
      })


      this.user.userAuthReload();
  }
  get sendDataForm()
  {
    return this.UserFormValue.controls
  }

  signUp(data:signUp):void
  {
      console.warn(data);
      this.user.userSignUp(data);    
  }

  login(data:Login)
  {
    console.warn(data);
    this.user.userLogin(data);
    this.user.invalidUserAuth.subscribe((result)=>{
      console.warn(result);
      if(result)
      {
        alert("User Not Found ! ");
      }
      else{
        this.localCartToremoteCart();
        let data = localStorage.getItem('localCart');
        let user = localStorage.getItem('user');
        let userId = user && JSON.parse(user).id;
        if(data)
        {
          let cartDataList:product[] = JSON.parse(data);
          cartDataList.forEach((product:product,index)=>{
              let cartData:cart={
                ...product,
                productId:product.id,
                userId
              }
              delete cartData.id;
              setTimeout(() => {
                this.product.addToCart(cartData).subscribe((result)=>{
                  if(result)
                  {
                    console.warn("data is stored in db");
                    
                  }
                })
              }, 500);
              if(cartDataList.length===index+1)
              {
                localStorage.removeItem('localCart');
              }
          })
        }

        setTimeout(() => {
          this.product.getCartList(userId)
        }, 2000);
      }
    })

  }
  openSignUp()
  {
      this.showLogin=false;
  }
  openLogin()
  {
      this.showLogin=true;
  }
  localCartToremoteCart()
  {
    console.warn("called");
    
  }
}
