import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { product } from '../data-type';
import { ProductService } from '../services/product.service';
import { FormBuilder,FormGroup, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-seller-add-product',
  templateUrl: './seller-add-product.component.html',
  styleUrls: ['./seller-add-product.component.css']
})
export class SellerAddProductComponent implements OnInit {

  addProductMessage:string | undefined
  ProductValueAdd ! : FormGroup;

  
  constructor(private hp:HttpClient, private product:ProductService , private router:Router,private frmblder : FormBuilder ) {  }

  ngOnInit(): void {
    this.ProductValueAdd = this.frmblder.group({
      name:['',[Validators.required,Validators.minLength(3),Validators.maxLength(15)]],
      price:['',[Validators.required]],

      category:['',[Validators.required]],
      color:['',[Validators.required]],
      description:['',[Validators.required]],
      image:['',[Validators.required]]

    })
  }
  get sendDataForm()
  {
    return this.ProductValueAdd.controls
  }

  submit(data:product)
  {
    this.product.addProduct(data).subscribe((result)=>{
        console.warn(result)
        if(result)
        {
          this.addProductMessage="product is added successfully !";
          alert("product is added successfully !")
          this.hp.post('http://localhost:8080/products',JSON.stringify(result));
          this.router.navigate(['/seller-home']);
        }

    });
    // setTimeout(()=>{
    //   this.addProductMessage = undefined
    // }, 3000)
  }
}
